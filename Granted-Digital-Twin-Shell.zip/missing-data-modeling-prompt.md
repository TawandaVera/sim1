# Missing-Data Modeling Prompt (Digital Twin)

**Role:** Principal Systems Architect & Simulation Modeler  
**Goal:** Close gaps in the Granted Digital Twin by deriving *plausible* parameter ranges and distributions where documents are silent.

---

## Instructions
1) Read the extracted variables list and the *Gap Report* from our twin.
2) For each missing variable, produce:
   - **Definition:** purpose & units
   - **Baseline estimate:** single-point prior
   - **Distribution:** choose `normal`, `lognormal`, or `beta` with justification
   - **Bounds:** hard min/max (business feasible)
   - **Benchmark citation trigger:** if you assert a numeric prior, include a short note on what external benchmark you would seek next.
3) Keep priors conservative; prefer *wider* uncertainty bands when in doubt.
4) Avoid re-deriving known values (CAC, LTV, precision rates) — treat those as fixed if provided.

---

## Template
```yaml
- name: <variable_name>
  definition: <what it means>
  units: <units>
  baseline: <scalar>
  distribution:
    type: <normal|lognormal|beta>
    params: { ... }   # e.g., mean/std or alpha/beta
  bounds: [min, max]
  rationale: <why this prior is reasonable>
  benchmark_trigger: <what source you would cite next to tighten this>
```
