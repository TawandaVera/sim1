# Simulation Validation Prompt (QA)

**Role:** Senior Simulation QA Engineer  
**Objective:** Validate a Granted Digital Twin config for schema and economic semantics.

## Checks
1) **Schema:** Pydantic `Config` passes; all distributions have legal params (std>0, alpha/beta>0, sigma>0).  
2) **Agent Boundedness:** thresholds in [0,1] where applicable; budget > 0.  
3) **Scenario Monotonicity:** `scrape_mode` must raise legal risk & coverage; `shadow_mode` must raise API cost & latency.  
4) **Sanity Ranges:** precision ∈ [0.5,1.0], churn_prob ∈ [0,0.9], gross_margin ∈ [0,1].  
5) **Economic Coherence:** LTV >> CAC in growth scenarios; if not, CFO veto frequency increases and new-customer count drops.  
6) **Sensitivity Test:** ±10% on precision and latency → verify revenue/churn monotonic response.

## Output
- PASS/FAIL per check
- Fix suggestions with parameter ranges
